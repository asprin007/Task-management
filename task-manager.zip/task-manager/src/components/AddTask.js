// AddTask.js - Updated to include timestamp on creation
import React, { useState } from "react";
import { v4 as uuidv4 } from "uuid";

const AddTask = ({ setTasks }) => {
  const [task, setTask] = useState({ 
    title: "", 
    description: "", 
    priority: "Low" 
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!task.title.trim()) return;
    
    setTasks((prev) => [
      ...prev, 
      { 
        ...task, 
        id: uuidv4(), 
        completed: false,
        createdAt: new Date().toISOString() // Add timestamp for sorting
      }
    ]);
    
    setTask({ title: "", description: "", priority: "Low" });
  };

  return (
    <form className="mb-4" onSubmit={handleSubmit}>
      <div className="mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="Task Title"
          value={task.title}
          onChange={(e) => setTask({ ...task, title: e.target.value })}
          required
        />
      </div>
      <div className="mb-3">
        <textarea
          className="form-control"
          placeholder="Task Description"
          value={task.description}
          onChange={(e) => setTask({ ...task, description: e.target.value })}
        />
      </div>
      <div className="mb-3">
        <select 
          className="form-select" 
          value={task.priority} 
          onChange={(e) => setTask({ ...task, priority: e.target.value })}
        >
          <option value="Low">Low Priority</option>
          <option value="Medium">Medium Priority</option>
          <option value="High">High Priority</option>
        </select>
      </div>
      <button type="submit" className="btn btn-primary">Add Task</button>
    </form>
  );
};

export default AddTask;