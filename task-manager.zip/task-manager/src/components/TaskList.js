// TaskList.js - Updated with sorting and filtering
import React, { useState } from "react";
import TaskItem from "./TaskItem";

const TaskList = ({ tasks, setTasks }) => {
  const [sortBy, setSortBy] = useState("createdAt");
  const [filterPriority, setFilterPriority] = useState("All");
  const [filterStatus, setFilterStatus] = useState("All");

  // Filter tasks based on selected criteria
  const filteredTasks = tasks.filter(task => {
    return (filterPriority === "All" || task.priority === filterPriority) &&
           (filterStatus === "All" || 
            (filterStatus === "Completed" && task.completed) || 
            (filterStatus === "Active" && !task.completed));
  });

  // Sort filtered tasks based on selected criteria
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    switch (sortBy) {
      case "title":
        return a.title.localeCompare(b.title);
      case "priority":
        const priorityOrder = { "High": 1, "Medium": 2, "Low": 3 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      case "status":
        return a.completed === b.completed ? 0 : a.completed ? 1 : -1;
      default: // createdAt (default)
        return 0; // Maintain existing order which is by creation
    }
  });

  return (
    <div>
      <div className="d-flex justify-content-between mb-3">
        <div className="d-flex gap-2">
          <select 
            className="form-select" 
            value={sortBy} 
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="createdAt">Sort by: Date Added</option>
            <option value="title">Sort by: Title</option>
            <option value="priority">Sort by: Priority</option>
            <option value="status">Sort by: Status</option>
          </select>
          
          <select 
            className="form-select" 
            value={filterPriority} 
            onChange={(e) => setFilterPriority(e.target.value)}
          >
            <option value="All">All Priorities</option>
            <option value="Low">Low Priority</option>
            <option value="Medium">Medium Priority</option>
            <option value="High">High Priority</option>
          </select>
          
          <select 
            className="form-select" 
            value={filterStatus} 
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="All">All Tasks</option>
            <option value="Active">Active Tasks</option>
            <option value="Completed">Completed Tasks</option>
          </select>
        </div>
      </div>

      {sortedTasks.length === 0 ? (
        <p className="text-center">No tasks match your filters.</p>
      ) : (
        <ul className="list-group">
          {sortedTasks.map((task) => (
            <TaskItem key={task.id} task={task} setTasks={setTasks} />
          ))}
        </ul>
      )}
    </div>
  );
};

export default TaskList;